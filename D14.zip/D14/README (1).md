
# ML Project

## Overview

The project primarily focuses on predicting algebraic answer scores using advanced Natural Language Processing (NLP) embeddings and various regression algorithms. The embeddings were generated using MathBERT, GPT-2, and auto-tokenizers, which transformed the algebraic answers into dense vector representations. Principal Component Analysis (PCA) was then employed to reduce the dimensionality of the data while retaining significant variance. Several regression models, including Decision Trees, SVM, KNN, Random Forest, AdaBoost, and XGBoost, were utilized to predict the average scores. Hyperparameter tuning was performed using grid and randomized search techniques to optimize model performance. The integration of these NLP techniques with regression algorithms aimed to improve the precision and reliability of educational assessments by automating the grading of algebraic answers.

## Codes

### 1. DATA_FILES

This directory contains the following datasets used in the project:

- `Auto.xlsx`: Contains automotive-related data for model training and testing.
- `GPT2_reordered.xlsx`: Dataset reordered for GPT-2 embeddings.
- `MathBert.xlsx`: Contains data specific to MathBert embeddings.
- `testing_mathbert.xlsx`: Test dataset for evaluating MathBert embeddings.

### 2. EMBEDDING_CONVERTER

This directory includes scripts and notebooks for converting datasets into various embedding formats:

- `AUTOTOKEN_CONVERTER.py`: Script to convert automotive dataset into token embeddings.
- `GPT2.ipynb`: Jupyter notebook for converting datasets using GPT-2 embeddings.
- `mathbertconversion.py`: Script for converting datasets into MathBert embeddings.

### 3. ML_CODES

 
- `TESTING & LR TRAINING RESULTS.ipynb`: Contains the testing  and linear regression training results.
- `TRAINING-1.ipynb`: Training of algorithms like KNN REGRESSOR 
- `TRAINING-3.ipynb`: Training of algorithms mainly TREE ALGORTHMS AND BOOSTING 
- `TRAINING-4.ipynb`: Training of CAT BOOST
- `TRANiING-2.ipynb`: Training of algorithms like SVR

