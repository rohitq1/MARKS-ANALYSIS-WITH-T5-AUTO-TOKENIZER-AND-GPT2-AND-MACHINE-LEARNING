import pandas as pd
from transformers import AutoTokenizer, AutoModel

# Load your data
data = pd.read_excel('question.xlsx')  

tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")  
model = AutoModel.from_pretrained("bert-base-uncased")

def get_embeddings(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
    outputs = model(**inputs)
    return outputs.last_hidden_state[:, -1, :].detach().numpy()

data['embeddings'] = data['input'].apply(get_embeddings)

print(data['embeddings'].head())

data.to_excel('/output_file.xlsx')  
